# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
from .cinema4d_render_submitter import show_submitter

__all__ = ["show_submitter"]
